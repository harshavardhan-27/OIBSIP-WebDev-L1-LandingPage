# GameZone — Gaming Landing Page

## Project Overview
**GameZone** is a modern, responsive gaming landing page created for the **Oasis Infobyte Web Development & Designing Internship (OIBSIP)**.

- **Internship:** Oasis Infobyte Web Development Internship
- **Level:** Level 1
- **Task:** Task 1 — Landing Page
- **Project Name:** WebDev-L1-LandingPage

## Project Objective
The objective of this project is to create an engaging, visually striking landing page for a gaming brand using standard **HTML5** and **CSS3**. It demonstrates key frontend web development concepts including semantic structure, layout systems (CSS Flexbox and CSS Grid), fluid typography, media queries, and dark-themed visual aesthetics with neon accents.

---

## Technologies Used
- **HTML5:** Semantic elements (`<header>`, `<nav>`, `<main>`, `<section>`, `<article>`, `<footer>`).
- **CSS3:** Custom properties (CSS variables), modern color palette, gradients, box shadows, and transitions.
- **CSS Flexbox:** Alignment and spacing for navigation bar, buttons, and footer.
- **CSS Grid:** Multi-column responsive layout for featured game cards and about section.
- **CSS Media Queries:** Fluid layout adjustments across desktop, tablet, and mobile breakpoints.
- **No JavaScript:** Built entirely with pure HTML5 and CSS3 as specified in the task requirements.
- **No External Frameworks:** Zero dependencies on Bootstrap, Tailwind, React, or build tools.

---

## Features
- **Sticky Navigation Bar:** Remains at the top while scrolling with quick anchor navigation to `#home`, `#games`, `#about`, and `#contact`, plus an *Explore Games* call-to-action button.
- **Hero Section:** High-impact gaming headline (`PLAY YOUR OWN GAME.`), supporting description, dual call-to-action buttons, and an active status badge.
- **Adaptive Hero Background:** Displays the full desktop gaming setup (`hero-gaming-setup.png`) on desktop displays and smoothly switches to the mobile landscape visual (`landscape.jpeg`) on mobile devices via CSS media queries.
- **Featured Games Grid:** Three gaming cards showcasing title, genre category, description, and interactive links:
  - *Cyber Warriors* (Action)
  - *Lost Kingdom* (Adventure)
  - *Speed Legends* (Competitive)
- **Interactive Card Hover Effects:** Subtle lift animations, image scaling, and neon-green glow borders on hover.
- **About Section:** Two-column desktop layout highlighting the GameZone brand story and an emblem badge with `GZ` and `LEVEL UP`.
- **Contact Section:** Clean call-to-action card encouraging gamer interaction with a placeholder email button.
- **Footer:** Brand branding, copyright notice, and navigation shortcuts.
- **Smooth Anchor Scrolling:** Effortless navigation between sections using CSS `scroll-behavior: smooth`.

---

## Exact Folder Structure
```text
WebDev-L1-LandingPage/
│
├── images/
│   ├── cyber-warriors.png
│   ├── hero-gaming-setup.png
│   ├── landscape.jpeg
│   ├── lost-kingdom.png
│   └── speed-legends.png
│
├── screenshots/
│   ├── desktop.png
│   └── mobile.jpeg
│
├── index.html
├── README.md
└── style.css
```

---

## Image Asset Descriptions
All images are located inside the `images/` directory:
- `hero-gaming-setup.png`: High-resolution ultrawide gaming desk setup with neon RGB lighting used as the desktop hero background.
- `landscape.jpeg`: Scenic fantasy vista with a grand castle and river used as the mobile hero background.
- `cyber-warriors.png`: Neon-lit futuristic gaming arena representing the Action genre game card.
- `lost-kingdom.png`: Enchanted glowing emerald fantasy kingdom representing the Adventure genre game card.
- `speed-legends.png`: High-speed endurance prototype race car on a rain-slicked circuit representing the Competitive genre game card.

---

## Responsive Design Breakpoints
The landing page has been tested and optimized across all major device widths:
- **1440px (Desktop):** Expansive 3-column games grid, 2-column about section, sticky navigation with full links and CTA.
- **1024px (Laptop):** Proportional container padding and 2-column games grid.
- **768px (Tablet):** Compact layout, tablet-friendly navigation, stacked about section, mobile hero background transition.
- **390px (Mobile):** Single-column games grid, stacked buttons, optimized typography, zero horizontal scrolling.
- **320px (Small Mobile):** Carefully scaled padding and text ensuring clear legibility and accessibility.

---

## How to Run the Website
1. Clone or download the `WebDev-L1-LandingPage` repository folder to your computer.
2. Locate and double-click `index.html`.
3. The page will immediately open and render in any modern web browser (Google Chrome, Microsoft Edge, Mozilla Firefox, Safari, Brave) without needing Node.js, a web server, or internet connection.
4. (Optional) If using Visual Studio Code, right-click `index.html` and select **Open with Live Server**.

---

## Screenshots

### Desktop View
![Desktop Screenshot](screenshots/desktop.png)

### Mobile View
![Mobile Screenshot](screenshots/mobile.jpeg)

---

## Task Checklist
- [x] Exact project name: `WebDev-L1-LandingPage`
- [x] Exact folder structure with `images/`, `screenshots/`, `index.html`, `style.css`, and `README.md`
- [x] Built strictly using HTML5 and CSS3 (no JavaScript or third-party CSS frameworks)
- [x] Sticky navigation bar with functional anchor links
- [x] Hero section with desktop (`hero-gaming-setup.png`) and mobile (`landscape.jpeg`) background images
- [x] Responsive 3-card Featured Games section using CSS Grid
- [x] About section with 2-column layout on desktop and single-column on mobile
- [x] Contact section with placeholder `mailto:` button
- [x] Responsive footer with navigation and copyright info
- [x] Tested across 1440px, 1024px, 768px, 390px, and 320px viewport widths
- [x] Zero horizontal overflow and no broken assets

---

## License & Credits
Created for the **Oasis Infobyte Internship — Web Development & Designing (Level 1, Task 1)**.
All assets are included for demonstration and educational purposes.